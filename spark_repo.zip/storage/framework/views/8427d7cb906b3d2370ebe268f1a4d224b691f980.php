<header>
    <nav class="d-flex px-5 align-items-center">
        <a href="<?php echo e(url('/')); ?>" class="d-inline-block">
            <img src="<?php echo e(asset('assets/images/logo.png')); ?>" width="210px" alt="Logo" />
        </a>
        <ul class="d-flex list-unstyled align-items-center mb-0 mx-auto navbar-links">
            <li>
                <a href="<?php echo e(url('/about-us')); ?>" class="text-decoration-none"> About </a>
            </li>
            <li>
                <a href="#" class="text-decoration-none"> My Personal Dashboard </a>
            </li>
            <li>
                <a href="/pages/action_print.html" class="text-decoration-none"> My Action Plan </a>
            </li>
            <li>
                <a href="/pages/recources.html" class="text-decoration-none"> Resources </a>
            </li>
        </ul>
        <div class="user-auth-dropdown">
            <div class="dropdown">
                <button class="border-0 bg-transparent d-flex align-items-center" type="button"
                    data-bs-toggle="dropdown" aria-expanded="false">
                    <img src="../../assets/images/avatar.png" width="50px" height="50px" class="rounded-circle me-3"
                        alt="username" />
                    <span class="me-3">Sam Smith</span>
                    <i class="bi bi-chevron-down text-red"></i>
                </button>
                <ul class="dropdown-menu">
                    <li class="dropdown-item">
                        <a href="#" class="text-decoration-none d-block">Profile</a>
                    </li>
                    <li class="dropdown-item">
                        <a href="#" class="text-decoration-none d-block">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header><?php /**PATH C:\xampp\htdocs\spark\laravel\resources\views/components/header.blade.php ENDPATH**/ ?>