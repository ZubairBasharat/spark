<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>

    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta author="Mian Roshan" content="Full Stack developer" />
        <title>Spark&nbsp;|&nbsp;Home</title>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/libraries/bootstrap/bootstrap.min.css')); ?>" />
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/main.css')); ?>" />
        <script type="text/javascript" src="<?php echo e(asset('assets/libraries/jquery/jquery.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('assets/libraries/bootstrap/bootstrap.bundle.js')); ?>"></script>
    </head>
    <?php echo $__env->yieldContent('scripts'); ?>
</head>

<body>
    <div class="main-app-wrap">
        <?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>

</html>

<body><?php /**PATH D:\xampp_8\htdocs\laravel\resources\views/components/app.blade.php ENDPATH**/ ?>