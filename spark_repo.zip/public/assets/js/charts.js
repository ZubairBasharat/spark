



    const ctx3 = document.getElementById("meaning-group-chart").getContext("2d");


const ctx4 = document.getElementById("progress-group-chart").getContext("2d");
const ctx5 = document.getElementById("dougnut-chart").getContext("2d");